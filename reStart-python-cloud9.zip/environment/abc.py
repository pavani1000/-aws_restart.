myString = "This is a string."
print(myString)
This is a string.
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))