myString = "This is a string."
print(myString)

